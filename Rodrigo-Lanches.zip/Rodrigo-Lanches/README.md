Estudante: Rodrigo Destri Perozin.
Formações atuais: Técnico em Desenvolvimento de Sistemas.
Descrição: Meu primeiro projeto no github, futuramente postarei vários.
