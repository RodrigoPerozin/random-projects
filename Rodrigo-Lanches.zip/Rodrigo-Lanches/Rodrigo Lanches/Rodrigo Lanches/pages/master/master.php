<h2 style="text-align: center;">Menu Master</h2><br>
<ul>
    <li>Usuários:
        <ul>
            <a href="inicio.php?folder=master/&file=insFun.php" style="text-decoration-color: #ffc107;"><h2><li>Registrar usuário</li></h2></a>
            <a href="inicio.php?folder=master/&file=delFun.php" style="text-decoration-color: #ffc107;"><h2><li>Remover usuário</li></h2></a>
            <a href="inicio.php?folder=master/&file=visuFun.php" style="text-decoration-color: #ffc107;"><h2><li>Visualizar usuários</li></h2></a>
        </ul>
    </li>                    
</ul>
<ul>
    <li>Horários:
        <ul>
            <a href="inicio.php?folder=master/&file=horarioFun.php" style="text-decoration-color: #ffc107;"><h2><li>Definir horário de espediente de um usuário</li></h2></a>
            <a href="inicio.php?folder=master/&file=horarioLan.php" style="text-decoration-color: #ffc107;"><h2><li>Definir horário de funcionamento da lanchonete</li></h2></a>
        </ul>
    </li>                    
</ul> 