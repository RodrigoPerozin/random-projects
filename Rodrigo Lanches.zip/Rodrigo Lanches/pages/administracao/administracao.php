<h2 style="text-align: center;">Menu administração</h2><br>
<ul>
    <a href="inicio.php?folder=administracao/&file=visuCardapio.php" style="text-decoration-color: #ffc107;"><li>Visualizar cardápio</li></a>
    <a href="inicio.php?folder=administracao/&file=frmins.php" style="text-decoration-color: #ffc107;"><li>Cadastrar novo item no cardápio</li></a>
    <a href="inicio.php?folder=administracao/&file=visuPedidos.php" style="text-decoration-color: #ffc107;"><li>Visualizar pedidos</li></a>
</ul>