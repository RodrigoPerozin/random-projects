function categoriaInfo(A){
    document.getElementById("categoria").value = A;
}