<h2 style="text-align: center;">Notícias</h2><br>
<div class="row">
    <ul>
        <div class="col-8 yellow-bar">
            <li style="list-style: none;">Convocamos a atenção de todos, para informar que a todos os meses após este mês, teremos um funcionário do mês.</li>
        </div><br>
        <div class="col-8 yellow-bar">
            <li style="list-style: none;">Benefícios do funcionário do mês:
                <ol>
                    <li>Aumento de 6% no salário do mês.</li>
                    <li>vale 30R$ na nossa lanchonete.</li>
                </ol>
            </li>
        </div>
    </ul><br>
</div>