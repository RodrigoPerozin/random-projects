<h2 style="text-align: center;">Menu funcionário</h2><br>
<ul>
    <a href="inicio.php?folder=funcionarios/&file=frmins.php" style="text-decoration-color: #ffc107;"><h2><li>Registrar pedido</li></h2></a>
    <a href="inicio.php?folder=funcionarios/&file=confirmar.php" style="text-decoration-color: #ffc107;"><h2><li>Confirmar pagamento</li></h2></a>
    <a href="inicio.php?folder=funcionarios/&file=visuCardapioFun.php" style="text-decoration-color: #ffc107;"><h2><li>Visualizar cardápio</li></h2></a>
    <a href="inicio.php?folder=funcionarios/&file=visuPedidoFun.php" style="text-decoration-color: #ffc107;"><h2><li>Visualizar meus pedidos</li></h2></a>
</ul>       