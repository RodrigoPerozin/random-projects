Estudante: Rodrigo Destri Perozin.
Formações atuais: Técnico em Desenvolvimento de Sistemas. Cursando superior em TADS.
Descrição: Meu primeiro projeto no github, futuramente postarei vários.
