package br.com.ficticiusclean.rest;

import java.util.ArrayList;
import java.util.Date;
import java.util.GregorianCalendar;

import br.com.ficticiusclean.model.*;
import br.com.ficticiusclean.view.View;

public class Api {

	public static void main(String[] args) {
		
		Factory factory = new Factory();
		int option;
		double gasolinePrice;
		double totalKmCity, totalKmRoad;
		
		do{
			
			option = View.askMenuOption(factory.getCars().size());
			System.out.print("Ação index: "+option+"\n");
			
			if((factory.getCars().size()==0 && option==1) || (factory.getCars().size()>0 && option==4)) {
				
				option = -1;
			
			}else if(option==0) {
				
				Car newCar= new Car();
				ArrayList<Object> parameters = View.getCarParameters();
				Date newDateFab = new Date();
				
				if(!parameters.isEmpty()){
					
					newCar.setName(parameters.get(0).toString());
					newCar.setBrand(parameters.get(1).toString());
					newCar.setModel(parameters.get(2).toString());
					newCar.setConsAvgCity(Double.parseDouble(parameters.get(3).toString()));
					newCar.setConsAvgRoad(Double.parseDouble(parameters.get(4).toString()));
//					
					newDateFab = new GregorianCalendar(
							Integer.parseInt(parameters.get(7).toString()), 
							Integer.parseInt(parameters.get(6).toString())-1, 
							Integer.parseInt(parameters.get(5).toString())
					).getTime();
					newCar.setDateFab(newDateFab);
					
					factory.addCar(newCar);
					
					if(factory.getCars().contains(newCar)) {
						View.msg("Carro cadastrado!");
					}
					
				}
				
			}else if(option==1) {
				
				Car carToEdit = View.getCarToAction(factory.getCars());
				Car editedCar= new Car();
				Date dateFabEdit = new Date();
				ArrayList<Object> editParameters = View.getCarEditParameters(carToEdit);
				editedCar.setName(editParameters.get(0).toString());
				editedCar.setBrand(editParameters.get(1).toString());
				editedCar.setModel(editParameters.get(2).toString());
				editedCar.setConsAvgCity(Double.parseDouble(editParameters.get(3).toString()));
				editedCar.setConsAvgRoad(Double.parseDouble(editParameters.get(4).toString()));
				
				if(Integer.parseInt(editParameters.get(7).toString())==0 
					&& Integer.parseInt(editParameters.get(6).toString())==0 
					&& Integer.parseInt(editParameters.get(5).toString())==0)
				{
					editedCar.setDateFab(carToEdit.getDateFab());
				}else {
				
					dateFabEdit = new GregorianCalendar(
							Integer.parseInt(editParameters.get(7).toString()), 
							Integer.parseInt(editParameters.get(6).toString())-1, 
							Integer.parseInt(editParameters.get(5).toString())
					).getTime();
					editedCar.setDateFab(dateFabEdit);
				}
				
				factory.replaceCar(carToEdit, editedCar);
				
			}else if(option==2) {
				
				Car carToRemove = View.getCarToAction(factory.getCars());
				factory.remCar(carToRemove);
				
				if(!factory.getCars().contains(carToRemove)) {
					View.msg("Carro removido!");
				}
				
			}else if(option==3) {
				
				gasolinePrice = View.getGasolinePrice();
				totalKmCity = View.getTotalKmCity();
				totalKmRoad = View.getTotalKmRoad();
				
				
				
			}
			
		}while(option!=-1);

	}

}
