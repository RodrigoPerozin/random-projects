package br.com.ficticiusclean.view;
import java.util.ArrayList;
import java.util.Calendar;

import javax.swing.*;

import br.com.ficticiusclean.model.*; 

public class View {

	public static int askMenuOption(int listCarSize) {
		
		JComboBox menuList;
		
		String optionsMenuComplete[] =
			{
				"Cadastrar veículo",
				"Editar veículo",
				"Excluir veículo",
				"Previsão de gastos",
				"Sair"
			};
		
		String optionsMenuFirst[] =
			{
				"Cadastrar veículo",
				"Sair"
			};
		
		if(listCarSize==0) {
			menuList = new JComboBox(optionsMenuFirst);
		}else {
			menuList = new JComboBox(optionsMenuComplete);
		}
		
		JOptionPane.showMessageDialog(null, menuList, "Menu", JOptionPane.QUESTION_MESSAGE);
		return menuList.getSelectedIndex();
	}

	public static ArrayList<Object> getCarParameters() {
		
		ArrayList<Object> params = new ArrayList<Object>();
		String name="", brand="", model="";
		double consAvgCity=0, consAvgRoad=0;
		int dayFab=0, monthFab=0, yearFab=0;
		try {
			
			
			do {
				name = JOptionPane.showInputDialog("Informe o nome do carro:");
				if(name.isBlank()) {
					msg("Informe um nome válido!");
				}
			}while(name.isBlank());
			
			do {
				brand = JOptionPane.showInputDialog("Informe a marca do carro:");
				if(brand.isBlank()) {
					msg("Informe uma marca válida!");
				}
			}while(brand.isBlank());
			
			do {
				model = JOptionPane.showInputDialog("Informe o modelo do carro:");
				if(model.isBlank()) {
					msg("Informe um modelo válido!");
				}
			}while(model.isBlank());
			
			do {
				consAvgCity = Double.parseDouble(JOptionPane.showInputDialog("Informe o consumo médio de combustível em Km/L do carro dentro de cidade:"));
				if(consAvgCity<=0) {
					msg("Informe um consumo médio de combustível válido!");
				}
			}while(consAvgCity<=0);
			
			do {
				consAvgRoad = Double.parseDouble(JOptionPane.showInputDialog("Informe o consumo médio de combustível em Km/L do carro dentro de rodovias:"));
				if(consAvgRoad<=0) {
					msg("Informe um consumo médio de combustível válido!");
				}
			}while(consAvgRoad<=0);
			
			do {
				dayFab = Integer.parseInt(JOptionPane.showInputDialog("Informe o dia de fabricação do carro:"));
				if(dayFab<=0 && dayFab>31) {
					msg("Informe um dia válido!");
				}
			}while(dayFab<=0 && dayFab>31);
			
			do {
				monthFab = Integer.parseInt(JOptionPane.showInputDialog("Informe o mês de fabricação do carro:"));
				if(monthFab<=0 && monthFab>12) {
					msg("Informe um mês válido!");
				}
			}while(monthFab<=0 && monthFab>12);
			
			do {
				yearFab = Integer.parseInt(JOptionPane.showInputDialog("Informe o ano de fabricação do carro:"));
				if(yearFab<=1900 && yearFab>Calendar.getInstance().get(Calendar.YEAR)) {
					msg("Informe um ano válido!");
				}
			}while(yearFab<=0 && yearFab>Calendar.getInstance().get(Calendar.YEAR));
			
			params.add(name);
			params.add(brand);
			params.add(model);
			params.add(consAvgCity);
			params.add(consAvgRoad);
			params.add(dayFab);
			params.add(monthFab);
			params.add(yearFab);
		}catch(Exception e) {
			params.clear();
			msg("Ops! Alguma informação foi preenchida incorretamente! Tente Novamente!");
		}
		
		return params;
	}

	public static void msg(String msg) {
		
		JOptionPane.showMessageDialog(null, msg);
		
	}

	public static Car getCarToAction(ArrayList<Car> carList) {
		
		String optionsCars[] = new String[carList.size()];
		String optionstr="";
		for(Car car: carList){
			
			optionstr+=
					car.getName()
					+" - "+car.getBrand()
					+" - "+car.getModel()
					+" - CTY "+car.getConsAvgCity()
					+" - ROA "+car.getConsAvgRoad()
					+" - "+(car.getDateFab().getDate())+"/"+(car.getDateFab().getMonth())+"/"+(car.getDateFab().getYear()+1900);
			
			optionsCars[carList.indexOf(car)] = optionstr;
			optionstr="";
		}
		
		try {
			
		}catch(Exception e) {
			e.printStackTrace();
			msg("Ops! Houve algum erro!");
		}
		
		JComboBox<String> menuListCarToAction = new JComboBox<String>(optionsCars);
		JOptionPane.showMessageDialog(null, menuListCarToAction, "Selecione para editar", JOptionPane.QUESTION_MESSAGE);
		
		return carList.get(menuListCarToAction.getSelectedIndex());
	}

	public static ArrayList<Object> getCarEditParameters(Car carToEdit) {
		
		ArrayList<Object> editParams = new ArrayList<Object>();
		String nameEdit="", brandEdit="", modelEdit="";
		double consAvgCityEdit=0, consAvgRoadEdit=0;
		int dayFabEdit=0, monthFabEdit=0, yearFabEdit=0, selectedMenu;
		boolean stop =false;
		
		try {
			
			do {
				
				String optionsEdit[] = {"Editar Nome", "Editar Marca", "Editar Modelo", "Editar Con. Med. em cidade", "Editar Con. Med. em rodovia", "Editar data de fabrição"};
				JComboBox<String> menuEdit = new JComboBox<String>(optionsEdit);
				JOptionPane.showMessageDialog(null, menuEdit, "Menu de edição", JOptionPane.QUESTION_MESSAGE);
				
				selectedMenu = menuEdit.getSelectedIndex();
				
				switch(selectedMenu) {
					case 0:
						do {
							nameEdit = JOptionPane.showInputDialog("Informe o novo nome do carro(Atual: '"+carToEdit.getName()+"'):");
							if(nameEdit.isBlank()) {
								msg("Informe um nome válido!");
							}
						}while(nameEdit.isBlank());
					break;
					case 1:
						do {
							brandEdit = JOptionPane.showInputDialog("Informe a nova marca do carro(Atual: '"+carToEdit.getBrand()+"'):");
							if(brandEdit.isBlank()) {
								msg("Informe uma marca válida!");
							}
						}while(brandEdit.isBlank());
					break;
					case 2:
						do {
							modelEdit = JOptionPane.showInputDialog("Informe o novo modelo do carro(Atual: '"+carToEdit.getModel()+"'):");
							if(modelEdit.isBlank()) {
								msg("Informe um modelo válido!");
							}
						}while(modelEdit.isBlank());
					break;
					case 3:
						do {
							consAvgCityEdit = Double.parseDouble(JOptionPane.showInputDialog("Informe o novo consumo médio de combustível em Km/L do carro dentro de cidade(Atual: '"+carToEdit.getConsAvgCity()+"Km/L'):"));
							if(consAvgCityEdit<=0) {
								msg("Informe um consumo médio de combustível válido!");
							}
						}while(consAvgCityEdit<=0);
					break;
					case 4:
						do {
							consAvgRoadEdit = Double.parseDouble(JOptionPane.showInputDialog("Informe o novo consumo médio de combustível em Km/L do carro dentro de rodovias(Atual: '"+carToEdit.getConsAvgRoad()+"Km/L'):"));
							if(consAvgRoadEdit<=0) {
								msg("Informe um consumo médio de combustível válido!");
							}
						}while(consAvgRoadEdit<=0);
					break;
					case 5:
						do {
							dayFabEdit = Integer.parseInt(JOptionPane.showInputDialog("Informe o dia atualizado de fabricação do carro(Atual: '"+carToEdit.getDateFab().getDate()+"':"));
							if(dayFabEdit<=0 && dayFabEdit>31) {
								msg("Informe um dia válido!");
							}
						}while(dayFabEdit<=0 && dayFabEdit>31);
						
						do {
							monthFabEdit = Integer.parseInt(JOptionPane.showInputDialog("Informe o mês atualizado de fabricação do carro(Atual: '"+carToEdit.getDateFab().getMonth()+"':"));
							if(monthFabEdit<=0 && monthFabEdit>12) {
								msg("Informe um mês válido!");
							}
						}while(monthFabEdit<=0 && monthFabEdit>12);
						
						do {
							yearFabEdit = Integer.parseInt(JOptionPane.showInputDialog("Informe o ano atualizado de fabricação do carro(Atual: '"+(carToEdit.getDateFab().getYear()+1900)+"':"));
							if(yearFabEdit<=1900 && yearFabEdit>Calendar.getInstance().get(Calendar.YEAR)) {
								msg("Informe um ano válido!");
							}
						}while(yearFabEdit<=0 && yearFabEdit>Calendar.getInstance().get(Calendar.YEAR));
					break;
				}
				
				String[] optionsYesNo = {"Sim", "Não"};
		        int indexAwnser = JOptionPane.showOptionDialog(null, "Deseja continuar editando?",
		                "Responder",
		                JOptionPane.DEFAULT_OPTION, JOptionPane.INFORMATION_MESSAGE, null, optionsYesNo, optionsYesNo[0]);
		        if(indexAwnser==1) {
		        	stop=true;
		        }
				
			}while(stop=false);
			
			editParams.add(nameEdit);
			editParams.add(brandEdit);
			editParams.add(modelEdit);
			editParams.add(consAvgCityEdit);
			editParams.add(consAvgRoadEdit);
			editParams.add(dayFabEdit);
			editParams.add(monthFabEdit);
			editParams.add(yearFabEdit);
		}catch(Exception e) {
			e.printStackTrace();
			editParams.clear();
			msg("Ops! Alguma informação foi editada incorretamente! Tente Novamente!");
		}
		
		return editParams;
	}

	public static double getGasolinePrice() {
		
		double gasolinePrice=0;
		do {
			gasolinePrice = Double.parseDouble(JOptionPane.showInputDialog("Informe o preço da gasolina em R$:"));
			if(gasolinePrice<=0) {
				msg("Informe um preço de gasolina válido!");
			}
		}while(gasolinePrice<=0);
		
		return gasolinePrice;
	}

	public static double getTotalKmCity() {
		
		double totalKmCity=0;
		do {
			totalKmCity = Double.parseDouble(JOptionPane.showInputDialog("Informe o total de km que será percorrido dentro da cidade:"));
			if(totalKmCity<=0) {
				msg("Informe um total de km válido!");
			}
		}while(totalKmCity<=0);
		
		return totalKmCity;
		
	}

	public static double getTotalKmRoad() {
		
		double totalKmRoad=0;
		do {
			totalKmRoad = Double.parseDouble(JOptionPane.showInputDialog("Informe o total de km que será percorrido em rodovias:"));
			if(totalKmRoad<=0) {
				msg("Informe um total de km válido!");
			}
		}while(totalKmRoad<=0);
		
		return totalKmRoad;
		
	}
	
}
