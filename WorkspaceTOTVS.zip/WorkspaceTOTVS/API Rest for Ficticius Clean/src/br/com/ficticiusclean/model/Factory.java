package br.com.ficticiusclean.model;

import java.util.ArrayList;

public class Factory {

	private ArrayList<Car> carList = new ArrayList<Car>();
	
	public void addCar(Car newCar) {
		
		this.carList.add(newCar);
		
	}
	
	public boolean remCar(Car newCar) {
		
		return this.carList.remove(newCar);
		
	}
	
	public ArrayList<Car> getCars(){
		
		return this.carList;
		
	}
	
public void replaceCar(Car modelCar, Car newCar) {
	
		if(!newCar.getName().isBlank()) {
			this.carList.get(this.carList.indexOf(modelCar)).setName(newCar.getName());
		}
		
		if(!newCar.getModel().isBlank()) {
			this.carList.get(this.carList.indexOf(modelCar)).setModel(newCar.getModel());
		}
		
		if(!newCar.getBrand().isBlank()) {
			this.carList.get(this.carList.indexOf(modelCar)).setBrand(newCar.getBrand());
		}
		
		if(!(newCar.getConsAvgCity()<=0)) {
			this.carList.get(this.carList.indexOf(modelCar)).setConsAvgCity(newCar.getConsAvgCity());
		}
		
		if(!(newCar.getConsAvgRoad()<=0)) {
			this.carList.get(this.carList.indexOf(modelCar)).setConsAvgRoad(newCar.getConsAvgRoad());
		}
		
		if(!(newCar.getDateFab().compareTo(modelCar.getDateFab())==0)) {
			this.carList.get(this.carList.indexOf(modelCar)).setDateFab(newCar.getDateFab());
		}
		
	}
	
}
