package br.com.ficticiusclean.model;

import java.util.Date;

public class Car {

	private String name;
	private String brand;
	private String model;
	private Date dateFab;
	private double consAvgCity, consAvgRoad;
	
	public void setName(String nome) {
		this.name = nome;
	}
	
	public void setBrand(String marca) {
		this.brand = marca;
	}
	
	public void setModel(String modelo) {
		this.model = modelo;
	}
	
	public void setDateFab(Date dataFab) {
		this.dateFab = dataFab;
	}
	
	public void setConsAvgCity(double consAvgCity) {
		this.consAvgCity = consAvgCity;
	}
	
	public void setConsAvgRoad(double consAvgRoad) {
		this.consAvgRoad = consAvgRoad;
	}
	
	public String getName() {
		return this.name;
	}
	
	public String getBrand() {
		return this.brand;
	}
	
	public String getModel() {
		return this.model;
	}
	
	public Date getDateFab() {
		return this.dateFab;
	}
	
	public double getConsAvgCity() {
		return this.consAvgCity;
	}
	
	public double getConsAvgRoad() {
		return this.consAvgRoad;
	}
	
}
